# initial version automatically generated from release-process/scripts/mk_exim_release.pl
EXIM_RELEASE_VERSION=4.87
EXIM_VARIANT_VERSION=
EXIM_COMPILE_NUMBER=0
