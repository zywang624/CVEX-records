/*************************************************
*     Exim - an Internet mail transport agent    *
*************************************************/

/*
 * Copyright (c) Wolfgang Breyha 2005
 * See the file NOTICE for conditions of use and distribution.
 *
 * original dccifd_localscan
 * Copyright (c) Christopher Bodenstein 2003-2005
 * <cb@physicman.net>
*/

#ifdef EXPERIMENTAL_DCC
/* currently empty */
#endif
